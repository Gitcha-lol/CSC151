// Spencer Ordonez January 11th, 2024 Test
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from CSC 151");
		System.out.println("How deez phat ballz taste?");


	}

}
