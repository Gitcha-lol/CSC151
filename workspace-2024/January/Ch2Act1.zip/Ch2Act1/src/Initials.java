// Spencer Ordonez January 25th, 2024 Activity 1

public class Initials {

	public static void main(String[] args) {
		char init1 = 'S';
		char init2 = 'G';
		char init3 = 'O';
		System.out.println(init1+"."+init2+"."+init3+".");
	}

}
